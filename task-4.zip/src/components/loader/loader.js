import Component from '../../app/js/base/component';

class Loader extends Component {
    constructor(element) {
        super(element);

        // Your code here
    }

    // Your code here
}

export default Loader