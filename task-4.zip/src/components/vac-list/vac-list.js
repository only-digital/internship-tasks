import Component from '../../app/js/base/component';

class VacList extends Component {
    constructor(element) {
        super(element);

        // Your code here
    }

    // Your code here
}

export default VacList